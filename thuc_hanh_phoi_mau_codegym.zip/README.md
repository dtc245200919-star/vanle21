# Bài Thực Hành: Sử Dụng Màu Sắc Trong Trang Web

- **Chủ đề:** Phối màu đơn tông (Monochromatic Palette) dựa trên màu logo CodeGym (`#00ADEE`).

---

## 🎨 Bảng phối màu chi tiết

| Cấp độ màu | Mã Hex | Thành phần áp dụng |
| :--- | :---: | :--- |
| **Bậc 1 (Màu chính)** | `#00ADEE` | Header, Badge `ON SALE` |
| **Bậc 2** | `#00B2EF` | Nút bấm `PREVIEW` |
| **Bậc 4** | `#00BFF2` | Màu nền toàn trang (`body`) |
| **Bậc 7** | `#8DD7F7` | Màu nền Khung nội dung (`product-container`) |
| **Bậc 9** | `#C6E9FA` | Màu nền Chân trang (`footer`) |
| **Chữ & Nền thẻ** | `#000000` / `#FFFFFF` | Thẻ sản phẩm & Nội dung văn bản |

---

## 🚀 Hướng dẫn upload lên GitHub:
1. Giải nén file zip này ra máy tính.
2. Mở Repository của bạn trên GitHub.
3. Kéo thả 3 file (`index.html`, `style.css`, `README.md`) vào ô Upload.
4. Nhấn **Commit changes** để hoàn tất.
